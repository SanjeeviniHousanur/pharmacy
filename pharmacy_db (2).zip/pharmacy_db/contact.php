<?php include('partials-front/menu.php'); ?>
<html>
    <head>
   <div class=text-center> 
<h2>phone-no:</h2><P><b>9481537661</b><P><br><br>
<h2>email:</h2><p><b>product@gmail.com</b></p>
</div>
</head>
</html>