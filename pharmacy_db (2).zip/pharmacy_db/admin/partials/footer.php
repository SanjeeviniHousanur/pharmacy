<div class="footer">
    <div class="wrapper">
    
        <p class="text-center">pharmacy management website <a href="#"> </a></p>

    </div>
    </div>